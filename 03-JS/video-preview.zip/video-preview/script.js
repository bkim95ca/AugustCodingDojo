console.log("page loaded...");

function playVideo(video) {
    video.play();
}

function pauseVideo(video) {
    video.pause();
}